﻿
namespace TestCodecare.Models
{
    public class PlayerModel
    {
        public string Name { get; set; }
        public int Score { get; set; }

    }
}
