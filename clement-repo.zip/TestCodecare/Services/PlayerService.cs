﻿using System.Collections.ObjectModel;
using TestCodecare.Models;

namespace TestCodecare.Services
{
    public class PlayerService
    {
        private ObservableCollection<PlayerModel> _players;

        public PlayerService()
        {
            _players = InitializePlayers();
        }

        public ObservableCollection<PlayerModel> GetPlayers()
        {
            return _players;
        }

        public void AddPlayer(PlayerModel player)
        {
            _players.Add(player);
        }

        public void DeletePlayer(PlayerModel player)
        {
            _players.Remove(player);
        }

        private ObservableCollection<PlayerModel> InitializePlayers()
        {
            return new ObservableCollection<PlayerModel>
            {
                new PlayerModel { Name = "Joueur 1", Score = 100 },
                new PlayerModel { Name = "Joueur 2", Score = 150 },
            };
        }
    }
}