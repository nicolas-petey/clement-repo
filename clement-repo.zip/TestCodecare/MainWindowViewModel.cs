﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using TestCodecare.Helpers_NePasModifier;
using TestCodecare.Models;
using TestCodecare.Services;

namespace TestCodecare
{
    public class MainWindowViewModel : ViewModel
    {
        public string NewPlayerName { get; set; }
        public int NewPlayerScore { get; set; }
        public ICommand AddPlayerCommand { get; }
        public ICommand CloseCommand { get; }
        public ICommand DeletePlayerCommand { get; }

        private readonly PlayerService _playerService;


        private ObservableCollection<PlayerModel> _playersList;
        public ObservableCollection<PlayerModel> PlayersList
        {
            get => _playersList;
            set => SetValueAndRaiseEventIfPropertyChanged(nameof(PlayersList), ref _playersList, value);
        }

        private string _label;
        public string Label
        {
            get => _label;
            set => SetValueAndRaiseEventIfPropertyChanged(nameof(Label), ref _label, value);
        }

        public int TotalPoints => PlayersList.Sum(player => player.Score);

        public MainWindowViewModel(PlayerService playerService)
        {
            _playerService = playerService;
            PlayersList = _playerService.GetPlayers();
            CloseCommand = CommandHelper.Create(() => System.Windows.Application.Current.Shutdown());
            AddPlayerCommand = CommandHelper.Create(AddPlayer);
            DeletePlayerCommand = CommandHelper.Create<PlayerModel>(DeletePlayer);
        }

        private void DeletePlayer(PlayerModel player)
        {
            _playerService.DeletePlayer(player);
            PlayersList.Remove(player);
            RaisePropertyChanged(nameof(TotalPoints));
        }

        private void AddPlayer()
        {
            if (!string.IsNullOrEmpty(NewPlayerName) && NewPlayerScore >= 0)
            {
                try
                {
                    _playerService.AddPlayer(new PlayerModel { Name = NewPlayerName, Score = NewPlayerScore });
                    NewPlayerName = string.Empty;
                    NewPlayerScore = 0;
                    RaisePropertyChanged(nameof(NewPlayerName)); 
                    RaisePropertyChanged(nameof(NewPlayerScore));
                    RaisePropertyChanged(nameof(PlayersList));
                    RaisePropertyChanged(nameof(TotalPoints));
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Erreur lors de l'ajout du joueur : {ex.Message}");
                }
            }
            else
            {
                Debug.WriteLine("Tentative d'ajout d'un joueur avec un nom vide ou un score invalide");
            }
        }
    }
}