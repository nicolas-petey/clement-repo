﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TestCodecare.Services;

namespace TestCodecare
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PlayerService playerService = new PlayerService();
            DataContext = new MainWindowViewModel(playerService);
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is DataGrid dataGrid)
            {
                foreach (var item in dataGrid.Items)
                {
                    var row = dataGrid.ItemContainerGenerator.ContainerFromItem(item) as DataGridRow;
                    if (row != null)
                    {
                        var button = FindVisualChild<Button>(row, "ButtonSupprimer");
                        if (button != null)
                        {
                            button.Visibility = (item == dataGrid.SelectedItem) ? Visibility.Visible : Visibility.Collapsed;
                        }
                    }
                }
            }
        }

        private T FindVisualChild<T>(DependencyObject obj, string name) where T : FrameworkElement
        {
            for (var i = 0; i < VisualTreeHelper.GetChildrenCount(obj); i++)
            {
                var child = VisualTreeHelper.GetChild(obj, i);
                if (child != null && child is T t && child is FrameworkElement frameworkElement && frameworkElement.Name == name)
                {
                    return t;
                }
                else
                {
                    var childOfChild = FindVisualChild<T>(child, name);
                    if (childOfChild != null)
                    {
                        return childOfChild;
                    }
                }
            }
            return null;
        }
    }
}